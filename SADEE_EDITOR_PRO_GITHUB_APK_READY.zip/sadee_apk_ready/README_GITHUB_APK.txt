SADEE EDITOR PRO - GitHub APK build

1. Create a new GitHub repository (e.g. sadee-editor-pro).
2. Upload/extract all files from this ZIP into the repository root.
3. Commit to main (or master). GitHub Actions will start building automatically.
4. On GitHub open: repository > Actions > Build SADEE EDITOR PRO APK.
5. Open the completed run and download the artifact named SADEE-EDITOR-PRO-APK.
6. Extract the artifact ZIP to find app-debug.apk.

If workflow doesn't start: Actions tab > Build SADEE EDITOR PRO APK > Run workflow.

This wraps the supplied web prototype in Capacitor for Android. It is not a signed release APK; debug APK only. The app's existing feature limitations remain.
