SADEE EDITOR PRO APK BUILD

1. Upload the contents of sadee_apk_ready to your GitHub repository root (including .github folder).
2. Ensure only the updated build-apk.yml workflow is enabled. Remove/disable older workflows that call setup-android@v3.
3. Commit and push to main/master or run it from Actions > SADEE EDITOR PRO APK BUILD > Run workflow.
4. After a successful run, download the SADEE-EDITOR-PRO-APK artifact.

This workflow creates a www folder from index.html, app.js, and style.css, uses Capacitor webDir=www, generates Android, syncs and builds a debug APK.
