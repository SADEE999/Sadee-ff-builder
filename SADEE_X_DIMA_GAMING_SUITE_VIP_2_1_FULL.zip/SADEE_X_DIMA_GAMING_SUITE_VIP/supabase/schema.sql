
-- SADEE X DIMA Gaming Suite — Supabase schema
-- Run in Supabase SQL Editor. Never put service_role keys in Android apps.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.admin_users where user_id=auth.uid()) $$;

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  created_at timestamptz not null default now()
);
create table if not exists public.packages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  duration_days integer,
  price_lkr integer not null check(price_lkr >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
insert into public.packages(name,duration_days,price_lkr)
select v.name,v.days,v.price from (values
 ('7 Days',7,1000),('1 Month',30,2500),('Lifetime',null::integer,4500)
) as v(name,days,price)
where not exists(select 1 from public.packages p where p.name=v.name);

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  license_key text unique not null,
  package_id uuid references public.packages(id),
  username text,
  user_id uuid references auth.users(id),
  status text not null default 'unused' check(status in ('unused','active','revoked','expired')),
  device_id text,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  username text not null,
  package_id uuid references public.packages(id),
  package_name text not null,
  amount_lkr integer not null,
  phone text not null default '+94768472404',
  status text not null default 'pending' check(status in ('pending','paid','cancelled')),
  created_at timestamptz not null default now()
);
create table if not exists public.devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  device_id text not null unique,
  username text,
  model text,
  manufacturer text,
  android_version text,
  total_storage_bytes bigint,
  available_storage_bytes bigint,
  last_seen timestamptz not null default now(),
  access_suspended boolean not null default false
);

alter table public.admin_users enable row level security;
alter table public.profiles enable row level security;
alter table public.packages enable row level security;
alter table public.licenses enable row level security;
alter table public.orders enable row level security;
alter table public.devices enable row level security;

drop policy if exists "active packages readable" on public.packages;
create policy "active packages readable" on public.packages for select using(active or public.is_admin());
drop policy if exists "admin manage packages" on public.packages;
create policy "admin manage packages" on public.packages for all using(public.is_admin()) with check(public.is_admin());

drop policy if exists "profile owner read" on public.profiles;
create policy "profile owner read" on public.profiles for select using(user_id=auth.uid() or public.is_admin());
drop policy if exists "profile owner insert" on public.profiles;
create policy "profile owner insert" on public.profiles for insert with check(user_id=auth.uid());
drop policy if exists "profile owner update" on public.profiles;
create policy "profile owner update" on public.profiles for update using(user_id=auth.uid() or public.is_admin()) with check(user_id=auth.uid() or public.is_admin());

drop policy if exists "admin manage licenses" on public.licenses;
create policy "admin manage licenses" on public.licenses for all using(public.is_admin()) with check(public.is_admin());
drop policy if exists "user read own licenses" on public.licenses;
create policy "user read own licenses" on public.licenses for select using(user_id=auth.uid());

drop policy if exists "admin manage orders" on public.orders;
create policy "admin manage orders" on public.orders for all using(public.is_admin()) with check(public.is_admin());
drop policy if exists "user read own orders" on public.orders;
create policy "user read own orders" on public.orders for select using(user_id=auth.uid());

drop policy if exists "admin manage devices" on public.devices;
create policy "admin manage devices" on public.devices for all using(public.is_admin()) with check(public.is_admin());
drop policy if exists "user manage own device" on public.devices;
create policy "user manage own device" on public.devices for all using(user_id=auth.uid()) with check(user_id=auth.uid());

drop policy if exists "admin read self" on public.admin_users;
create policy "admin read self" on public.admin_users for select using(user_id=auth.uid() or public.is_admin());

-- Admin bootstrap: after creating your admin account in Authentication > Users,
-- insert its UUID manually:
-- insert into public.admin_users(user_id) values ('YOUR-AUTH-USER-UUID');


-- VIP device limits (safe migration for existing projects)
alter table public.licenses
  add column if not exists max_devices integer not null default 1
  check (max_devices between 1 and 10);
alter table public.licenses
  add column if not exists device_ids text[] not null default '{}';

-- Preserve any previously activated single-device binding.
update public.licenses
set device_ids = array[device_id]
where device_id is not null
  and coalesce(cardinality(device_ids), 0) = 0;

-- Atomically claim a device slot so simultaneous activations cannot exceed the limit.
create or replace function public.claim_license_device(
  p_license_id uuid,
  p_device_id text,
  p_user_id uuid,
  p_username text,
  p_expiry timestamptz
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  lic public.licenses%rowtype;
  ids text[];
begin
  if p_device_id is null or length(trim(p_device_id)) < 4 then
    return jsonb_build_object('success', false, 'error', 'Invalid device identifier');
  end if;

  select * into lic from public.licenses
    where id = p_license_id for update;

  if not found then
    return jsonb_build_object('success', false, 'error', 'License not found');
  end if;
  if lic.status in ('revoked', 'expired') then
    return jsonb_build_object('success', false, 'error', 'License is not active');
  end if;
  if lic.expires_at is not null and lic.expires_at < now() then
    update public.licenses set status = 'expired' where id = lic.id;
    return jsonb_build_object('success', false, 'error', 'License expired');
  end if;
  if lic.user_id is not null and lic.user_id <> p_user_id then
    return jsonb_build_object('success', false, 'error', 'License belongs to another account');
  end if;

  ids := coalesce(lic.device_ids, '{}');
  if not (p_device_id = any(ids)) then
    if cardinality(ids) >= lic.max_devices then
      return jsonb_build_object(
        'success', false,
        'error', 'Device limit reached',
        'device_count', cardinality(ids),
        'max_devices', lic.max_devices
      );
    end if;
    ids := array_append(ids, p_device_id);
  end if;

  update public.licenses
    set status = 'active',
        user_id = p_user_id,
        username = coalesce(nullif(p_username, ''), username),
        device_ids = ids,
        device_id = ids[1],
        expires_at = coalesce(expires_at, p_expiry)
    where id = lic.id;

  return jsonb_build_object(
    'success', true,
    'device_count', cardinality(ids),
    'max_devices', lic.max_devices,
    'expires_at', coalesce(lic.expires_at, p_expiry)
  );
end;
$$;

revoke all on function public.claim_license_device(uuid,text,uuid,text,timestamptz) from public, anon, authenticated;
grant execute on function public.claim_license_device(uuid,text,uuid,text,timestamptz) to service_role;
