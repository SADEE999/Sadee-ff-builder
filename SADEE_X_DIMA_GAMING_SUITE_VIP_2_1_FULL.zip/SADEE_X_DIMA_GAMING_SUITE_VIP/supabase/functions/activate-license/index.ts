import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 try{
  const url=Deno.env.get("SUPABASE_URL")!, service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, anon=Deno.env.get("SUPABASE_ANON_KEY")!;
  const auth=req.headers.get("Authorization")??"";
  const uc=createClient(url,anon,{global:{headers:{Authorization:auth}}});
  const {data:{user}}=await uc.auth.getUser();
  if(!user) return Response.json({error:"Sign in required"},{status:401,headers:cors});
  const {license_key,device_id,username}=await req.json();
  const db=createClient(url,service);
  const {data:lic,error}=await db.from("licenses").select("id,package_id,status,expires_at").eq("license_key",String(license_key).trim()).maybeSingle();
  if(error||!lic) return Response.json({error:"Invalid license key"},{status:404,headers:cors});
  const {data:pkg,error:pe}=await db.from("packages").select("duration_days").eq("id",lic.package_id).single();
  if(pe) throw pe;
  const expiry=lic.expires_at || (pkg?.duration_days ? new Date(Date.now()+pkg.duration_days*86400000).toISOString() : null);
  const {data:claim,error:claimError}=await db.rpc("claim_license_device",{
    p_license_id:lic.id,
    p_device_id:String(device_id||""),
    p_user_id:user.id,
    p_username:String(username||""),
    p_expiry:expiry
  });
  if(claimError) throw claimError;
  if(!claim?.success) return Response.json(claim,{status:403,headers:cors});
  return Response.json(claim,{headers:cors});
 }catch(e){return Response.json({error:String(e)},{status:400,headers:cors});}
});
