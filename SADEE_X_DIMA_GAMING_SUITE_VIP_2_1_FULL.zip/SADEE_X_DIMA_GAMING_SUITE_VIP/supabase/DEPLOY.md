# Supabase deployment

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
supabase functions deploy create-order
supabase functions deploy admin-generate-keys
supabase functions deploy activate-license
supabase functions deploy register-device
```

Set secrets in the Supabase Dashboard under Edge Functions → Secrets. Do not add `SUPABASE_SERVICE_ROLE_KEY` to Android build config.


## VIP device-limit upgrade
1. Open Supabase SQL Editor and run the updated `schema.sql` (it is safe to re-run).
2. Deploy the updated `admin-generate-keys` and `activate-license` Edge Functions.
3. In Admin Panel > Create Keys, choose 1, 2, 3, 5, or 10 allowed devices.
4. The selected limit is stored with each new key. Existing keys default to one device.
5. Device binding is enforced in a database function using a row lock, so parallel activations cannot exceed the limit.

Do not put the Supabase service-role/secret key in either Android app or in the ZIP.
