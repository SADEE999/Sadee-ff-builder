# SADEE X DIMA VIP 2.1

- Admin key generator now lets the admin choose 1, 2, 3, 5, or 10 devices per license.
- The selected limit is saved on each generated license.
- Activation checks the allowed device list server-side.
- Existing license rows migrate with a default one-device limit; any prior bound device is preserved.
- Supabase service-role credentials remain server-side only.

## Required Supabase steps
Run `supabase/schema.sql`, then deploy the updated `admin-generate-keys` and `activate-license` Edge Functions. See `supabase/DEPLOY.md`.
