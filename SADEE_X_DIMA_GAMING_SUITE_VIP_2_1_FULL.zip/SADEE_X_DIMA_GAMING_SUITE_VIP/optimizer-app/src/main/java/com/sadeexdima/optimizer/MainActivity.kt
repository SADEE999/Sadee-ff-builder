package com.sadeexdima.optimizer

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject

private val Bg = Color(0xFF08070B)
private val Panel = Color(0xFF19090D)
private val Purple = Color(0xFFFF3038)
private val Green = Color(0xFF20C997)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OptimizerApp() }
    }
}

@Composable
fun OptimizerApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var page by remember { mutableIntStateOf(0) }
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var license by remember { mutableStateOf("") }
    var selectedGame by remember { mutableStateOf("Free Fire") }
    var message by remember { mutableStateOf("Ready") }
    var crosshair by remember { mutableStateOf(true) }
    var hud by remember { mutableStateOf(false) }
    var sens by remember { mutableIntStateOf(3) }
    var selectedPackage by remember { mutableStateOf("7 Days") }

    val tabs = listOf("Home", "Booster", "Tweaks", "Sensi & DPI", "Visual HUD", "Launch")
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                tabs.forEachIndexed { index, label ->
                    val icons = listOf(Icons.Default.Home, Icons.Default.Bolt, Icons.Default.Tune,
                        Icons.Default.TouchApp, Icons.Default.Visibility, Icons.Default.RocketLaunch)
                    NavigationBarItem(
                        selected = page == index,
                        onClick = { page = index },
                        icon = { Icon(icons[index], contentDescription = label) },
                        label = { Text(label, maxLines = 1, fontSize = 9.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Purple,
                            indicatorColor = Purple.copy(alpha = .18f),
                            selectedTextColor = Purple
                        )
                    )
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                AnimatedVisibility(visible = true, enter = fadeIn() + slideInVertically(initialOffsetY = { -24 })) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(R.drawable.sadee_x_dima_brand),
                            contentDescription = "SADEE X DIMA gaming artwork",
                            modifier = Modifier.size(76.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("SADEE X DIMA", color = Color(0xFFFF3038), fontWeight = FontWeight.Black, fontSize = 22.sp)
                            Text("GAMING OPTIMIZER PRO", color = Color.LightGray, fontSize = 11.sp)
                            Text("BOOST • OPTIMIZE • DOMINATE", color = Color(0xFFFF5555), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item {
                CardBox {
                    Text("DEVICE PERFORMANCE", color = Purple, fontWeight = FontWeight.Bold)
                    val manager = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    val memory = ActivityManager.MemoryInfo()
                    manager.getMemoryInfo(memory)
                    Text("Available RAM: ${memory.availMem / 1024 / 1024} MB", color = Color.White)
                    Text("Android ${Build.VERSION.RELEASE} • ${Build.MANUFACTURER} ${Build.MODEL}", color = Color.LightGray)
                    Text("FPS/GPU counters are not exposed to ordinary apps for other games.", color = Color.Gray, fontSize = 11.sp)
                }
            }
            when (page) {
                0 -> {
                    item {
                        CardBox {
                            Text("ACCOUNT & VIP LICENSE", color = Purple, fontWeight = FontWeight.Bold)
                            OutlinedTextField(username, { username = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(email, { email = it }, label = { Text("Account email") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(password, { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        scope.launch {
                                            try {
                                                val result = SupabaseApi.signUp(email.trim(), password, username.trim())
                                                token = result.optString("access_token")
                                                message = if (token.isBlank()) "Account created. Verify email if required, then sign in." else "Account created and signed in."
                                            } catch (e: Exception) { message = e.message ?: "Sign-up failed" }
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("CREATE ACCOUNT") }
                                OutlinedButton(
                                    onClick = {
                                        scope.launch {
                                            try {
                                                token = SupabaseApi.signIn(email.trim(), password).getString("access_token")
                                                message = "Signed in successfully."
                                            } catch (e: Exception) { message = e.message ?: "Sign-in failed" }
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("SIGN IN") }
                            }
                            OutlinedTextField(license, { license = it }, label = { Text("VIP License Key") }, modifier = Modifier.fillMaxWidth())
                            Button(
                                onClick = {
                                    scope.launch {
                                        try {
                                            check(token.isNotBlank()) { "Sign in first." }
                                            val deviceId = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
                                            val response = SupabaseApi.edge(
                                                "activate-license", token,
                                                JSONObject().put("license_key", license.trim())
                                                    .put("device_id", deviceId).put("username", username)
                                            )
                                            message = if (response.optBoolean("success")) "VIP license activated." else "Activation response received."
                                        } catch (e: Exception) { message = e.message ?: "Activation failed" }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("ACTIVATE LICENSE") }
                            Text(if (token.isBlank()) "Not signed in" else "Account authenticated", color = Green, fontSize = 11.sp)
                            Text(message, color = Green, fontSize = 12.sp)
                        }
                    }
                    item {
                        CardBox {
                            Text("SELECT VIP PACKAGE", color = Purple, fontWeight = FontWeight.Bold)
                            listOf("7 Days" to "LKR 1,000", "1 Month" to "LKR 2,500", "Lifetime" to "LKR 4,500").forEach { (name, price) ->
                                FilterChip(selected = selectedPackage == name, onClick = { selectedPackage = name }, label = { Text("$name — $price") })
                            }
                            Button(
                                onClick = {
                                    scope.launch {
                                        try {
                                            check(token.isNotBlank()) { "Sign in first to create an order." }
                                            val rows = SupabaseApi.select("packages", token, "select=id,name,price_lkr&active=eq.true")
                                            val pkg = (0 until rows.length()).map { rows.getJSONObject(it) }
                                                .firstOrNull { it.optString("name") == selectedPackage }
                                                ?: error("Selected package is unavailable. Check Supabase packages.")
                                            val result = SupabaseApi.edge(
                                                "create-order", token,
                                                JSONObject().put("package_id", pkg.getString("id")).put("username", username)
                                            )
                                            val orderId = result.optJSONObject("order")?.optString("id") ?: "pending"
                                            val text = "Hi, I placed a VIP order. Package: ${pkg.optString("name")} (LKR ${pkg.optInt("price_lkr")}). Order ID: $orderId"
                                            val url = "https://wa.me/94768472404?text=" + java.net.URLEncoder.encode(text, "UTF-8")
                                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                        } catch (e: Exception) { message = e.message ?: "Order failed" }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Green)
                            ) { Text("CREATE WHATSAPP ORDER") }
                            OutlinedButton(
                                onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chat.whatsapp.com/Ht0AHPYHPGj7Rp1setOwJ5?s=cl&p=a&iam=2"))) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("JOIN WHATSAPP GROUP") }
                        }
                    }
                }
                1 -> item {
                    CardBox {
                        Text("RAM & SYSTEM STATUS", color = Purple, fontWeight = FontWeight.Bold)
                        Text("Android restricts normal apps from force-stopping other apps.", color = Color.LightGray)
                        Button(onClick = { message = "Memory status refreshed." }, modifier = Modifier.fillMaxWidth()) { Text("REFRESH MEMORY STATUS") }
                        Text(message, color = Green)
                    }
                }
                2 -> item {
                    CardBox {
                        Text("GAMING TWEAKS", color = Purple, fontWeight = FontWeight.Bold)
                        listOf("Use in-game low graphics for steadier performance", "Close unused apps manually", "Keep the device cool", "Avoid battery saver during gameplay").forEach {
                            Text("• $it", color = Color.White, modifier = Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
                3 -> item {
                    CardBox {
                        Text("SENSITIVITY & DPI REFERENCE", color = Purple, fontWeight = FontWeight.Bold)
                        Text("Choose a personal preset. This does not edit game files.", color = Color.LightGray)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            (1..7).forEach { n -> FilterChip(selected = sens == n, onClick = { sens = n }, label = { Text("$n") }) }
                        }
                        Text("PRESET $sens", color = Purple)
                    }
                }
                4 -> item {
                    CardBox {
                        Text("VISUAL HUD & CROSSHAIR", color = Purple, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Overlay permission", color = Color.White, modifier = Modifier.weight(1f))
                            Switch(checked = hud, onCheckedChange = { hud = it })
                        }
                        if (hud) {
                            Button(onClick = {
                                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                            }) { Text("OPEN OVERLAY PERMISSION") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Crosshair preference", color = Color.White, modifier = Modifier.weight(1f))
                            Switch(checked = crosshair, onCheckedChange = { crosshair = it })
                        }
                        Text("This starter does not draw over games or claim unavailable FPS readings.", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
                5 -> item {
                    CardBox {
                        Text("INITIALIZE BOOST MAX & LAUNCH", color = Purple, fontWeight = FontWeight.Bold)
                        Text("Select game", color = Color.White)
                        listOf("Free Fire", "Free Fire MAX").forEach { game ->
                            FilterChip(selected = selectedGame == game, onClick = { selectedGame = game }, label = { Text(game) })
                        }
                        Button(onClick = { launchGame(ctx, selectedGame) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.RocketLaunch, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("INITIALIZE & LAUNCH")
                        }
                        Text("Opens the selected game if installed; it cannot silently clean or terminate other apps.", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }
            item { Text("SADEE X DIMA • Build 1.1", color = Color.Gray, fontSize = 10.sp) }
        }
    }
}

@Composable
private fun BrandMark() {
    Surface(shape = RoundedCornerShape(14.dp), color = Purple, modifier = Modifier.size(54.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text("S×D", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp), content = content)
    }
}

private fun launchGame(ctx: Context, game: String) {
    val packageName = if (game == "Free Fire") "com.dts.freefireth" else "com.dts.freefiremax"
    val launchIntent = ctx.packageManager.getLaunchIntentForPackage(packageName)
    if (launchIntent != null) ctx.startActivity(launchIntent)
    else ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
}
