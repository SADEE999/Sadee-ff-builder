package com.sadeexdima.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject

private val Bg = Color(0xFF08070B)
private val Panel = Color(0xFF19090D)
private val Purple = Color(0xFFFF3038)
private val Green = Color(0xFF20C997)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AdminApp() }
    }
}

@Composable
fun AdminApp() {
    val scope = rememberCoroutineScope()
    var page by remember { mutableIntStateOf(0) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var packageName by remember { mutableStateOf("7 Days") }
    var count by remember { mutableStateOf("10") }\n    var maxDevices by remember { mutableIntStateOf(1) }
    var token by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Sign in with the Supabase admin account.") }
    var keys by remember { mutableStateOf("") }
    var orders by remember { mutableStateOf("Orders will appear after backend setup.") }
    val pages = listOf("Dashboard", "Create Keys", "Packages", "Orders", "Settings")

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                val icons = listOf(Icons.Default.Dashboard, Icons.Default.Key, Icons.Default.Inventory, Icons.Default.Receipt, Icons.Default.Settings)
                pages.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = page == index,
                        onClick = { page = index },
                        icon = { Icon(icons[index], contentDescription = label) },
                        label = { Text(label, fontSize = 9.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, indicatorColor = Purple.copy(alpha = .2f))
                    )
                }
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                AnimatedVisibility(visible = true, enter = fadeIn() + slideInVertically(initialOffsetY = { -24 })) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(R.drawable.sadee_x_dima_brand),
                            contentDescription = "SADEE X DIMA admin branding",
                            modifier = Modifier.size(76.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("SADEE X DIMA", color = Color(0xFFFF3038), fontWeight = FontWeight.Black, fontSize = 22.sp)
                            Text("OWNER ADMIN PANEL", color = Color.LightGray, fontSize = 11.sp)
                            Text("CONTROL • MANAGE • DOMINATE", color = Color(0xFFFF5555), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            when (page) {
                0 -> item {
                    AdminCard {
                        Text("ADMIN DASHBOARD", color = Purple, fontWeight = FontWeight.Bold)
                        if (token.isBlank()) {
                            Text("OWNER SIGN-IN", color = Color.White, fontWeight = FontWeight.Bold)
                            OutlinedTextField(email, { email = it }, label = { Text("Admin email") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(password, { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = {
                                scope.launch {
                                    try {
                                        token = SupabaseApi.signIn(email.trim(), password).getString("access_token")
                                        status = "Signed in. Admin privileges are checked by Supabase."
                                        page = 0
                                    } catch (e: Exception) { status = e.message ?: "Sign-in failed" }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("SIGN IN TO ADMIN") }
                        }
                        Text(if (token.isBlank()) "Not authenticated" else "Admin session authenticated", color = Color.White)
                        Text(status, color = Color.LightGray)
                        Button(onClick = {
                            scope.launch {
                                try {
                                    check(token.isNotBlank()) { "Sign in first." }
                                    val data = SupabaseApi.select("orders", token, "select=id,username,package_name,amount_lkr,status,created_at&order=created_at.desc")
                                    orders = (0 until data.length()).joinToString("\n") { i ->
                                        val row = data.getJSONObject(i)
                                        "${row.optString("username")} • ${row.optString("package_name")} • LKR ${row.optInt("amount_lkr")} • ${row.optString("status")}"
                                    }.ifBlank { "No orders yet." }
                                    status = "Dashboard refreshed."
                                } catch (e: Exception) { status = e.message ?: "Refresh failed" }
                            }
                        }) { Text("REFRESH ORDERS") }
                        Text(orders, color = Color.White, fontSize = 12.sp)
                    }
                }
                1 -> item {
                    AdminCard {
                        Text("✦ VIP LICENSE KEY GENERATOR", color = Color(0xFFE9C46A), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)\n                        Text("Choose how many devices each generated key can activate.", color = Color.LightGray, fontSize = 12.sp)
                        OutlinedTextField(username, { username = it }, label = { Text("Customer username (optional)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(count, { count = it }, label = { Text("Number of keys (1–200)") }, modifier = Modifier.fillMaxWidth())
                        listOf("7 Days", "1 Month", "Lifetime").forEach { name ->
                            FilterChip(selected = packageName == name, onClick = { packageName = name }, label = { Text(name) })
                        }
                        Text("ALLOWED DEVICES PER KEY", color = Color(0xFFE9C46A), fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            listOf(1, 2, 3, 5, 10).forEach { n ->
                                FilterChip(
                                    selected = maxDevices == n,
                                    onClick = { maxDevices = n },
                                    label = { Text("$n") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFF6B1824),
                                        selectedLabelColor = Color(0xFFFFD978)
                                    )
                                )
                            }
                        }
                        Text(
                            "Each key will work on up to $maxDevices device${if (maxDevices == 1) "" else "s"}.",
                            color = Color(0xFFE9C46A), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                        )
                        Button(
                            onClick = {
                                scope.launch {
                                    try {
                                        check(token.isNotBlank()) { "Admin sign in first." }
                                        val packages = SupabaseApi.select("packages", token, "select=id,name,price_lkr&active=eq.true")
                                        val selected = (0 until packages.length()).map { packages.getJSONObject(it) }
                                            .firstOrNull { it.optString("name") == packageName }
                                            ?: error("Package '$packageName' not found. Run supabase/schema.sql.")
                                        val response = SupabaseApi.edge(
                                            "admin-generate-keys", token,
                                            JSONObject().put("package_id", selected.getString("id"))
                                                .put("count", count.toIntOrNull() ?: 1).put("username", username).put("max_devices", maxDevices)
                                        )
                                        val generated = response.optJSONArray("keys") ?: error("No keys returned.")
                                        keys = (0 until generated.length()).joinToString("\n") { generated.getJSONObject(it).optString("license_key") }
                                        status = "Generated ${generated.length()} key(s)."
                                    } catch (e: Exception) { status = e.message ?: "Key generation failed" }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("GENERATE KEYS") }
                        if (keys.isNotBlank()) Text(keys, color = Green, fontSize = 12.sp)
                        Text(status, color = Color.LightGray, fontSize = 12.sp)
                    }
                }
                2 -> item {
                    AdminCard {
                        Text("PACKAGE PRICES", color = Purple, fontWeight = FontWeight.Bold)
                        Text("7 Days — LKR 1,000", color = Color.White)
                        Text("1 Month — LKR 2,500", color = Color.White)
                        Text("Lifetime — LKR 4,500", color = Color.White)
                        Text("Package edits are managed in the Supabase packages table in this build.", color = Color.LightGray)
                    }
                }
                3 -> item {
                    AdminCard {
                        Text("ORDERS", color = Purple, fontWeight = FontWeight.Bold)
                        Text(orders, color = Color.White)
                        Text("Verify payment independently before changing an order status.", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
                4 -> item {
                    AdminCard {
                        Text("SECURITY & SUPPORT", color = Purple, fontWeight = FontWeight.Bold)
                        Text("Admin access is authenticated through Supabase. Protected Edge Functions validate admin permissions.", color = Color.White)
                        Text("Never place a Supabase secret/service-role key in this APK.", color = Color.LightGray, fontSize = 12.sp)
                        Text("Support: +94 76 847 2404", color = Color.White)
                        Text(status, color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }
            item { Text("SADEE X DIMA • Admin VIP Build 2.1", color = Color.Gray, fontSize = 10.sp) }
        }
    }
}

@Composable
private fun AdminCard(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}
