# SADEE X DIMA Gaming Suite

Two Android app modules:
- `optimizer-app`: customer account, license activation, package selection, order creation and Free Fire / Free Fire MAX launcher.
- `admin-app`: admin sign-in, license key generation, package overview and order viewing.

## Supabase configuration already applied
`gradle.properties` contains the supplied project URL and publishable client key. The publishable key is intended for client-side use and is protected by RLS/Edge Function authorization. No `service_role` or `sb_secret_...` value is included in this project.

**Security:** the secret key previously pasted into chat should be revoked and rotated in Supabase. Store the replacement only in Supabase Edge Function Secrets as `SUPABASE_SERVICE_ROLE_KEY`. Never put it in Gradle properties, GitHub source, or either APK.

## Backend setup
1. Run `supabase/schema.sql` in the Supabase SQL Editor.
2. Create your admin account in Supabase Authentication > Users.
3. Insert the admin user's UUID:
   `insert into public.admin_users(user_id) values ('YOUR-AUTH-USER-UUID');`
4. Deploy functions from the project root:
   - `supabase functions deploy create-order`
   - `supabase functions deploy admin-generate-keys`
   - `supabase functions deploy activate-license`
   - `supabase functions deploy register-device`
5. Configure Edge Function secrets in Supabase Dashboard. Do not expose the service role key.
6. Disable email confirmation only if that is your deliberate auth policy; otherwise users must verify their email before login.

## Build
Open the root folder in Android Studio with JDK 17, or use GitHub Actions. The workflow builds:
- `:optimizer-app:assembleDebug`
- `:admin-app:assembleDebug`

The workflow uploads separate APK artifacts.

## Prices and contact
- 7 Days — LKR 1,000
- 1 Month — LKR 2,500
- Lifetime — LKR 4,500
- WhatsApp: +94 76 847 2404
- Group: https://chat.whatsapp.com/Ht0AHPYHPGj7Rp1setOwJ5?s=cl&p=a&iam=2

## Honest platform limitations
Android normal apps cannot force-stop other apps, silently change another game's configuration, lock a whole device remotely, or read another game's private FPS/GPU counters. The app therefore does not fake those capabilities. Overlay permission is a user-controlled Android setting; this build provides the settings entry point, not a complete live FPS overlay. The device admin actions described earlier are not implemented as remote phone-control features.

## Branding / UI upgrade 2.0
- User-provided SADEE X DIMA red dragon artwork is included in both apps as the launcher icon and in-app header artwork.
- Red/black theme and animated header entrance added.
- Admin sign-in is embedded on the dashboard; there is no separate admin login screen.
- Optimizer sign-in remains in the customer home/account area.
