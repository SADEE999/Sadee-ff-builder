package com.sadee.poster;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.util.Base64;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER = 101;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8,9,20));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8,9,20));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(8,9,20));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                try { startActivityForResult(Intent.createChooser(i, "Select screenshots"), FILE_PICKER); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
        });
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void savePoster(String dataUrl) {
                runOnUiThread(() -> {
                    try {
                        byte[] bytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(",")+1), Base64.DEFAULT);
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.Images.Media.DISPLAY_NAME, "SADEE_POSTER_" + System.currentTimeMillis() + ".png");
                        v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                        v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SADEE Poster Pro");
                        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                        if (uri == null) throw new Exception("Gallery file unavailable");
                        OutputStream out = getContentResolver().openOutputStream(uri); out.write(bytes); out.close();
                        Toast.makeText(MainActivity.this, "Poster saved to Gallery", Toast.LENGTH_LONG).show();
                    } catch (Exception e) { Toast.makeText(MainActivity.this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
                });
            }
        }, "AndroidPoster");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req,result,data);
        if(req==FILE_PICKER && fileCallback!=null) {
            Uri[] uris=null;
            if(result==RESULT_OK && data!=null) {
                if(data.getClipData()!=null) {
                    int n=data.getClipData().getItemCount(); uris=new Uri[n];
                    for(int x=0;x<n;x++) uris[x]=data.getClipData().getItemAt(x).getUri();
                } else if(data.getData()!=null) uris=new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(uris); fileCallback=null;
        }
    }
    @Override public void onBackPressed() {
        if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}