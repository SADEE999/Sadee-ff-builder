package com.sadeexdima.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import org.json.JSONObject
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape

private val Bg=Color(0xFF08070B); private val Panel=Color(0xFF15111C); private val Purple=Color(0xFFAA4BE8)
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{AdminApp()}}}
@Composable fun AdminApp(){
 var page by remember{mutableIntStateOf(0)}
 var email by remember{mutableStateOf("")}; var password by remember{mutableStateOf("")}
 var username by remember{mutableStateOf("")}; var pack by remember{mutableStateOf("7 Days")}; var count by remember{mutableStateOf("10")}
 var status by remember{mutableStateOf("Set Supabase URL/anon key, then sign in with your admin Auth account.")}
 var token by remember{mutableStateOf("")}; var packageId by remember{mutableStateOf("")}; var generatedKeys by remember{mutableStateOf("")}
 val scope= rememberCoroutineScope()
 val pages=listOf("Dashboard","Create Keys","Packages","Users","Orders","Settings")
 Scaffold(containerColor=Bg,bottomBar={NavigationBar(containerColor=Panel){pages.forEachIndexed{i,p->NavigationBarItem(selected=page==i,onClick={page=i},icon={Icon(listOf(Icons.Default.Dashboard,Icons.Default.Key,Icons.Default.Inventory,Icons.Default.People,Icons.Default.Receipt,Icons.Default.Settings)[i],null)},label={Text(p,fontSize=9.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Purple,indicatorColor=Purple.copy(.2f)))}}}){pad->
 LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
 item{Text("SADEE X DIMA",color=Purple,fontSize=22.sp,fontWeight=FontWeight.Black);Text("OWNER ADMIN PANEL",color=Color.LightGray)}
 when(page){
 0->item{PanelCard{Text("ADMIN DASHBOARD",color=Purple,fontWeight=FontWeight.Bold);Text("License management • Orders • Devices",color=Color.White);Text(status,color=Color.LightGray);Button(onClick={status="Dashboard ready. Live counts require Supabase connection and RLS setup."}){Text("REFRESH DASHBOARD")}}}
 1->item{PanelCard{Text("GENERATE LICENSE KEYS",color=Purple,fontWeight=FontWeight.Bold);OutlinedTextField(username,{username=it},label={Text("Customer username")},modifier=Modifier.fillMaxWidth());OutlinedTextField(count,{count=it},label={Text("Number of keys")},modifier=Modifier.fillMaxWidth());Text("Package",color=Color.White);listOf("7 Days — Rs. 1,000","1 Month — Rs. 2,500","Lifetime — Rs. 4,500").forEach{FilterChip(selected=pack==it.substringBefore(" —"),onClick={pack=it.substringBefore(" —")},label={Text(it)})};Button(onClick={scope.launch { try { if(token.isBlank()) error("Admin sign in first."); val packages=SupabaseApi.select("packages",token,"select=id,name,price_lkr&active=eq.true"); if(packages.length()==0) error("No active package found."); val chosen=(0 until packages.length()).map{packages.getJSONObject(it)}.firstOrNull{it.optString("name")==pack} ?: packages.getJSONObject(0); packageId=chosen.getString("id"); val result=SupabaseApi.edge("admin-generate-keys",token,JSONObject().put("package_id",packageId).put("count",count.toIntOrNull()?:1).put("username",username)); val arr=result.optJSONArray("keys"); generatedKeys=(0 until (arr?.length()?:0)).joinToString("\\n"){arr!!.getJSONObject(it).optString("license_key")}; status="Generated ${arr?.length()?:0} key(s)." } catch(e:Exception){status=e.message ?: "Key generation failed"} }},modifier=Modifier.fillMaxWidth()){Text("GENERATE KEYS")}; if(generatedKeys.isNotBlank()) Text(generatedKeys,color=Color(0xFF20C997)); Text(status,color=Color.LightGray,fontSize=12.sp)}}
 2->item{PanelCard{Text("PACKAGE MANAGER",color=Purple,fontWeight=FontWeight.Bold);listOf("7 Days — LKR 1,000","1 Month — LKR 2,500","Lifetime — LKR 4,500").forEach{Text("• $it",color=Color.White)};Text("Add/edit/disable packages after connecting admin API.",color=Color.LightGray)}}
 3->item{PanelCard{Text("USER & DEVICE MANAGEMENT",color=Purple,fontWeight=FontWeight.Bold);Text("Registered device ID, model, Android version, storage and last-seen are available only after user consent and app registration.",color=Color.White);Text("Admin can suspend access to this app; Android does not permit a regular app to remotely lock the whole phone.",color=Color.LightGray)}}
 4->item{PanelCard{Text("ORDERS",color=Purple,fontWeight=FontWeight.Bold);Text("Pending / Paid / Cancelled orders are stored in Supabase once order and payment verification functions are deployed.",color=Color.White)}}
 5->item{PanelCard{Text("SECURITY & SETTINGS",color=Purple,fontWeight=FontWeight.Bold);OutlinedTextField(email,{email=it},label={Text("Admin email")},modifier=Modifier.fillMaxWidth());OutlinedTextField(password,{password=it},label={Text("Password")},modifier=Modifier.fillMaxWidth());Text("Admin authentication uses Supabase Auth. Never embed the service-role key in this APK.",color=Color.LightGray); Button(onClick={scope.launch { try { val auth=SupabaseApi.signIn(email,password); token=auth.getString("access_token"); status="Signed in. Admin role is checked by the backend." } catch(e:Exception){status=e.message ?: "Sign-in failed"} }},modifier=Modifier.fillMaxWidth()){Text("ADMIN SIGN IN")}; Text(if(token.isBlank()) "Not signed in" else "Authenticated session active",color=Color(0xFF20C997)); Text("Support: +94 76 847 2404",color=Color.White);Text(status,color=Color.LightGray)}}
 }
 }
 }
}
@Composable fun PanelCard(content:@Composable ColumnScope.()->Unit){Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp),content=content)}}
