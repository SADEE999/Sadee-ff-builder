package com.sadeexdima.optimizer

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import org.json.JSONObject
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF08070B)
private val Panel = Color(0xFF15111C)
private val Purple = Color(0xFFAA4BE8)
private val Green = Color(0xFF20C997)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { OptimizerApp() } }
}
@Composable fun OptimizerApp() {
    val ctx = LocalContext.current
    var page by remember { mutableIntStateOf(0) }
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var license by remember { mutableStateOf("") }
    var packageId by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    var selectedGame by remember { mutableStateOf("Free Fire") }
    var message by remember { mutableStateOf("Ready") }
    var crosshair by remember { mutableStateOf(true) }
    var hud by remember { mutableStateOf(true) }
    var sens by remember { mutableIntStateOf(3) }
    val tabs = listOf("Home","Booster","Tweaks","Sensi & DPI","Visual HUD","Launch")
    Scaffold(containerColor=Bg, bottomBar={ NavigationBar(containerColor=Panel) {
        tabs.forEachIndexed { i,t -> NavigationBarItem(selected=page==i,onClick={page=i},icon={ Icon(listOf(Icons.Default.Home,Icons.Default.Bolt,Icons.Default.Tune,Icons.Default.TouchApp,Icons.Default.Visibility,Icons.Default.RocketLaunch)[i],null) },label={Text(t,maxLines=1,fontSize=9.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Purple,indicatorColor=Purple.copy(.18f),selectedTextColor=Purple)) }
    }}) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
            item { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) { Column { Text("SADEE X DIMA",color=Purple,fontWeight=FontWeight.Black,fontSize=22.sp); Text("GAMING OPTIMIZER PRO",color=Color.LightGray,fontSize=11.sp) }; Text("● LIVE HUD",color=Green,fontSize=11.sp) } }
            item { CardBox { Column { Text("DEVICE PERFORMANCE",color=Purple,fontWeight=FontWeight.Bold); val am=ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager; val mi=ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); Text("RAM available: ${mi.availMem/1024/1024} MB",color=Color.White); Text("Android ${Build.VERSION.RELEASE} • ${Build.MANUFACTURER} ${Build.MODEL}",color=Color.LightGray); Text("CPU: app-process metrics not exposed as total-device CPU on standard Android",color=Color.Gray,fontSize=11.sp) } } }
            when(page) {
                0 -> {
                    item { CardBox { Column(verticalArrangement=Arrangement.spacedBy(8.dp)) { Text("WELCOME / LICENSE",color=Purple,fontWeight=FontWeight.Bold); OutlinedTextField(username,{username=it},label={Text("Username")},modifier=Modifier.fillMaxWidth()); OutlinedTextField(email,{email=it},label={Text("Account Email")},modifier=Modifier.fillMaxWidth()); OutlinedTextField(password,{password=it},label={Text("Password")},modifier=Modifier.fillMaxWidth()); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ Button(onClick={scope.launch { try { val a=SupabaseApi.signUp(email,password,username); token=a.optString("access_token"); if(token.isBlank()) message="Account created. Confirm email if enabled, then sign in." else message="Account created and signed in." } catch(e:Exception){message=e.message ?: "Sign-up failed"} }},modifier=Modifier.weight(1f)){Text("CREATE ACCOUNT")}; OutlinedButton(onClick={scope.launch { try { val a=SupabaseApi.signIn(email,password); token=a.getString("access_token"); message="Signed in successfully." } catch(e:Exception){message=e.message ?: "Sign-in failed"} }},modifier=Modifier.weight(1f)){Text("SIGN IN")} }; OutlinedTextField(license,{license=it},label={Text("VIP License Key")},modifier=Modifier.fillMaxWidth()); Button(onClick={scope.launch { try { if(token.isBlank()) error("Sign in first."); val id=android.provider.Settings.Secure.getString(ctx.contentResolver,android.provider.Settings.Secure.ANDROID_ID) ?: "unknown"; val result=SupabaseApi.edge("activate-license",token,JSONObject().put("license_key",license).put("device_id",id).put("username",username)); message=if(result.optBoolean("success")) "VIP license activated." else "Activation response received." } catch(e:Exception){message=e.message ?: "Activation failed"} }},modifier=Modifier.fillMaxWidth()) { Text("ACTIVATE LICENSE") }; Text(if(token.isBlank()) "Not signed in" else "Account authenticated",color=Green,fontSize=11.sp); Text(message,color=Green,fontSize=12.sp) } } }
                    item { CardBox { Column { Text("VIP PACKAGES",color=Purple,fontWeight=FontWeight.Bold); listOf("7 Days — Rs. 1,000","1 Month — Rs. 2,500","Lifetime — Rs. 4,500").forEach { Text("✦  $it",color=Color.White,modifier=Modifier.padding(5.dp)) } } } }
                    item { Button(onClick={scope.launch { try { if(token.isBlank()) error("Sign in first to create an order."); val rows=SupabaseApi.select("packages",token,"select=id,name,price_lkr&active=eq.true"); if(rows.length()==0) error("No active packages available."); val pkg=rows.getJSONObject(0); val order=SupabaseApi.edge("create-order",token,JSONObject().put("package_id",pkg.getString("id")).put("username",username)); val orderId=order.optJSONObject("order")?.optString("id") ?: ""; val msg="Hi, I placed a VIP order. Package: ${pkg.optString("name")} (LKR ${pkg.optInt("price_lkr")}). Order ID: $orderId"; ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/94768472404?text="+java.net.URLEncoder.encode(msg,"UTF-8")))) } catch(e:Exception){message=e.message ?: "Order failed"} }},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)) { Text("CREATE WHATSAPP ORDER") } }
                    item { OutlinedButton(onClick={ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://chat.whatsapp.com/Ht0AHPYHPGj7Rp1setOwJ5?s=cl&p=a&iam=2")))},modifier=Modifier.fillMaxWidth()) { Text("JOIN OFFICIAL GROUP") } }
                }
                1 -> item { CardBox { Column(verticalArrangement=Arrangement.spacedBy(10.dp)) { Text("RAM & SYSTEM BOOSTER",color=Purple,fontWeight=FontWeight.Bold); Text("Android does not allow force-stopping other apps from a normal app.",color=Color.LightGray); Button(onClick={ message="Memory status refreshed"; },modifier=Modifier.fillMaxWidth()) { Text("REFRESH MEMORY STATUS") }; Text(message,color=Green) } } }
                2 -> item { CardBox { Column { Text("GAMING TWEAKS",color=Purple,fontWeight=FontWeight.Bold); Text("Settings are advisory only; no hidden game-file edits.",color=Color.LightGray); listOf("Low-latency mode (supported game settings)","Close unused apps manually","Keep device cool","Disable battery saver while gaming").forEach { Text("• $it",color=Color.White,modifier=Modifier.padding(6.dp)) } } } }
                3 -> item { CardBox { Column { Text("SENSITIVITY AIM CORE",color=Purple,fontWeight=FontWeight.Bold); Text("Choose a personal preset (does not alter game files)",color=Color.LightGray); Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) { (1..7).forEach { n -> FilterChip(selected=sens==n,onClick={sens=n},label={Text("$n")}) } }; Text("PRESET $sens • Personal reference",color=Purple) }; var dpi by remember { mutableStateOf("Default") }; OutlinedTextField(dpi,{dpi=it},label={Text("DPI note (reference only)")}) } } }
                4 -> item { CardBox { Column { Text("VISUAL HUD & CROSSHAIR",color=Purple,fontWeight=FontWeight.Bold); Row(verticalAlignment=Alignment.CenterVertically) { Text("Floating HUD permission",Modifier.weight(1f),color=Color.White); Switch(hud,{hud=it}) }; if(hud) Button(onClick={ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:${ctx.packageName}")))}) { Text("GRANT OVERLAY PERMISSION") }; Row(verticalAlignment=Alignment.CenterVertically) { Text("Crosshair preference",Modifier.weight(1f),color=Color.White); Switch(crosshair,{crosshair=it}) }; Text("HUD can show only metrics Android exposes to this app. External game FPS/GPU counters are not generally available.",color=Color.LightGray,fontSize=12.sp) } } }
                5 -> item { CardBox { Column(verticalArrangement=Arrangement.spacedBy(10.dp)) { Text("INITIALIZE BOOST MAX & LAUNCH",color=Purple,fontWeight=FontWeight.Bold); Text("Select game",color=Color.White); listOf("Free Fire","Free Fire MAX").forEach { FilterChip(selected=selectedGame==it,onClick={selectedGame=it},label={Text(it)}) }; Button(onClick={ launchGame(ctx,selectedGame) },modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.RocketLaunch,null); Spacer(Modifier.width(8.dp)); Text("INITIALIZE & LAUNCH") }; Text("Refreshes memory information and opens the selected installed game. It cannot silently clean/kill other apps.",color=Color.LightGray,fontSize=12.sp) } } }
            }
            item { Text("Build 1.0 • Secure Supabase integration pending configuration",color=Color.Gray,fontSize=10.sp) }
        }
    }
}
@Composable fun CardBox(content:@Composable ColumnScope.()->Unit) { Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp),content=content) } }
fun launchGame(ctx:Context, game:String) { val pkg=if(game=="Free Fire") "com.dts.freefireth" else "com.dts.freefiremax"; val i=ctx.packageManager.getLaunchIntentForPackage(pkg); if(i!=null) ctx.startActivity(i) else ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))) }
