# SADEE X DIMA Gaming Suite

Two Android APK modules sharing one Supabase backend:
- `optimizer-app` — customer gaming companion, game launcher, package/order entry and license activation UI.
- `admin-app` — owner dashboard UI for packages, license keys, orders and registered devices.

## Build both APKs
Open the project in Android Studio (JDK 17), sync Gradle, then build:
- `:optimizer-app:assembleDebug`
- `:admin-app:assembleDebug`

GitHub Actions builds both APKs on push/manual dispatch and uploads separate artifacts. The supplied Supabase Project URL and publishable key are already configured in the root `gradle.properties`, so no GitHub Actions secrets are required for this starter. The publishable key is client-side; never add a `service_role`/secret key to either APK.

## Supabase setup (required before live use)
1. Create a Supabase project.
2. Run `supabase/schema.sql` in Supabase SQL Editor.
3. In Authentication > Users, create your own admin user (email/password).
4. Copy that user's UUID and run:
   `insert into public.admin_users(user_id) values ('YOUR-AUTH-USER-UUID');`
5. Deploy functions from the repository root using Supabase CLI:
   - `supabase functions deploy create-order`
   - `supabase functions deploy admin-generate-keys`
   - `supabase functions deploy activate-license`
   - `supabase functions deploy register-device`
6. Set Edge Function secrets (Supabase Dashboard > Edge Functions > Secrets):
   `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`.
   Supabase supplies the first/third values in hosted environments; ensure the service role secret is never copied into either APK.
7. The project URL and publishable key supplied by you are already set in the root `gradle.properties`. You can override them at build time with `-PSUPABASE_URL=... -PSUPABASE_ANON_KEY=...`.
8. Create customer accounts through Supabase Auth using email + password. Create your admin Auth user and add its UUID to `admin_users` as described above.
9. Run the GitHub Actions workflow (or build locally) to produce the two debug APK artifacts. Backend operations will only work after the SQL schema and Edge Functions have been deployed and the admin UUID has been bootstrapped. Test signup, login, ordering, activation and admin key generation on real devices before distributing.

## Customer pricing and contacts
- 7 days — LKR 1,000
- 1 month — LKR 2,500
- Lifetime — LKR 4,500
- WhatsApp orders: +94 76 847 2404
- Group: https://chat.whatsapp.com/Ht0AHPYHPGj7Rp1setOwJ5?s=cl&p=a&iam=2

## Important limitations / honest behavior
- Standard Android apps cannot reliably read another game's internal FPS/GPU counters. The optimizer must not fabricate these values.
- Android does not allow a normal app to force-stop other apps, silently alter game graphics/config files, or remotely lock the entire phone.
- Cross-app overlay requires the user to explicitly grant overlay permission. This starter includes the permission flow, not a fully implemented foreground overlay service.
- Device information should be registered only after clear user consent. Admin suspension disables access to this app when the app next checks in; it does not lock the device.
- Orders are recorded as pending. Payment confirmation must be performed by an admin after independently verifying payment; do not mark orders paid from a client request.
- The UI is a starter implementation. Review/test on real devices, complete customer account onboarding and live Supabase API wiring before distributing.

## Security
Never commit a Supabase service-role key, Android signing keystore, or passwords. Use Supabase Auth; do not store plaintext passwords in tables. Configure a privacy policy and data-safety disclosures before public release.


## Build status / important note
This ZIP contains configured Android source code, not prebuilt APKs. It has not been compiled or tested in this environment. A working Supabase URL and publishable key alone do not provision the database: you must still run `supabase/schema.sql`, deploy the four Edge Functions, configure function secrets, and bootstrap the admin user. Some dashboard/customer features in this starter are incomplete; do not treat it as production-ready until the flows are completed and tested.
