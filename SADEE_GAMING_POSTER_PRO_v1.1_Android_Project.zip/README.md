# SADEE GAMING POSTER PRO v1.1

Android poster-maker starter project.

## v1.1 improvements
- Multiple screenshot upload
- Assign each screenshot to Profile / Stats, Characters, Bundles / Outfits, Emotes, Gun Skins, Pets, Vehicles, or Other Items
- Poster generator groups photos into separate category sections and grid tiles
- Edit player name, UID, level and heading
- Export HD PNG to Gallery

## Build
Upload the project files to GitHub and run `.github/workflows/build-apk.yml`.
The workflow builds a debug APK and uploads it as an artifact.

## Important limitation
This version groups screenshots according to the category selected by the user. It does not yet use an AI vision model to identify game items automatically. A real automatic classifier requires an integrated vision model or a trained on-device model.
