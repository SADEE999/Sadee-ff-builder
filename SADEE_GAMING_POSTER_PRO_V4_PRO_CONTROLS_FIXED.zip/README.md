# SADEE GAMING POSTER PRO — V3.0 ULTIMATE

Android Studio project with a WebView-based poster editor.

## Features
- Original SADEE GAMING POSTER PRO icon/logo
- Animated splash/loading screen
- Premium dark neon gold / purple / crimson interface
- Multi-image gallery upload
- Eight manual screenshot categories
- Per-image editor: drag to reposition, zoom/crop, manual brush background eraser
- Profile name, UID, level, heading and footer editing
- Compact category-based poster composition
- HD PNG export to Android Pictures/SADEE Poster Pro
- GitHub Actions workflow builds a debug APK

## Build with GitHub
1. Extract this ZIP.
2. Upload the CONTENTS to the root of your GitHub repository (do not upload only the ZIP).
3. Open Actions and run "SADEE GAMING POSTER PRO V3 APK BUILDER".
4. Download artifact "SADEE-GAMING-POSTER-PRO-V3-APK" when the workflow succeeds.

## Important limitations
- Background removal in this version is a manual brush eraser, not automatic AI segmentation.
- Screenshot category selection is manual; the app does not yet identify individual game items automatically.
- This is an Android project source ZIP, not a prebuilt APK.

## V3 Loading-screen fix
- Logo PNG is now copied into `app/src/main/assets/` so WebView can load it offline.
- Added an independent splash-screen fail-safe so a JavaScript startup error cannot leave the app stuck on the loading screen.

## V4 PRO Controls and interaction repair
- Repaired the invalid JavaScript line break that prevented the main app script from starting.
- Repaired editor image rendering and manual erase compositing.
- Added 10 working design controls with 5 choices each (50 selectable style options).
- Design controls affect poster export: background, layout, frames, fit, columns, spacing, border, title alignment, header and more.
- Auto Arrange now sorts screenshots by selected category and refreshes the preview.
