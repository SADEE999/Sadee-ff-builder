# SADEE GAMING POSTER PRO

An Android WebView app starter for creating Free Fire-style account showcase posters from screenshots.

## Included in this first version
- Select multiple screenshots from the phone gallery
- Automatic collage layout
- Manual layout selection (Showcase / Grid / Wide)
- Edit player name, UID, level and poster title
- Preview poster on a canvas
- Export a PNG poster to Gallery (`Pictures/SADEE Poster Pro`)
- Dark gaming UI

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload all files and folders from this project.
3. Open **Actions** and run **Build Android APK** (or push to `main`).
4. Download the artifact named `SADEE-GAMING-POSTER-PRO-APK`.
5. Extract it to get `app-debug.apk`.

## Important
This is the working first MVP. It does not yet contain cloud-based AI recognition or automatic identification of every in-game item. The poster is assembled from the screenshots you select; the editor lets you adjust the layout and player details. Use screenshots and account details you have permission to use.
