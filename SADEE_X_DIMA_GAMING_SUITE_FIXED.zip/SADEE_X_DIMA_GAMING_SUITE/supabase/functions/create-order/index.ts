import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods":"POST, OPTIONS" };
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", {headers:cors});
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const userClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {global:{headers:{Authorization:authHeader}}});
    const {data:{user},error:userErr} = await userClient.auth.getUser();
    if (userErr || !user) return Response.json({error:"Sign in required"},{status:401,headers:cors});
    const {package_id, username} = await req.json();
    const {data:pkg,error:pkgErr} = await admin.from("packages").select("id,name,price_lkr,active").eq("id",package_id).single();
    if (pkgErr || !pkg?.active) return Response.json({error:"Package unavailable"},{status:400,headers:cors});
    const {data,error} = await admin.from("orders").insert({user_id:user.id,username:String(username||user.user_metadata?.username||"Customer"),package_id:pkg.id,package_name:pkg.name,amount_lkr:pkg.price_lkr}).select().single();
    if(error) throw error;
    return Response.json({order:data, whatsapp:"https://wa.me/94768472404"},{headers:cors});
  } catch(e) { return Response.json({error:String(e)},{status:400,headers:cors}); }
});
