import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 try{
  const url=Deno.env.get("SUPABASE_URL")!, service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, anon=Deno.env.get("SUPABASE_ANON_KEY")!;
  const auth=req.headers.get("Authorization")??"";
  const uc=createClient(url,anon,{global:{headers:{Authorization:auth}}});
  const {data:{user}}=await uc.auth.getUser();
  if(!user) return Response.json({error:"Sign in required"},{status:401,headers:cors});
  const {license_key,device_id,username}=await req.json();
  const db=createClient(url,service);
  const {data:lic,error}=await db.from("licenses").select("id,package_id,status,expires_at,username,user_id").eq("license_key",String(license_key).trim()).maybeSingle();
  if(error||!lic) return Response.json({error:"Invalid license key"},{status:404,headers:cors});
  if(lic.status==="revoked"||lic.status==="expired") return Response.json({error:"License is not active"},{status:403,headers:cors});
  if(lic.user_id && lic.user_id!==user.id) return Response.json({error:"License belongs to another account"},{status:403,headers:cors});
  const {data:pkg}=await db.from("packages").select("duration_days").eq("id",lic.package_id).single();
  const expiry=pkg?.duration_days ? new Date(Date.now()+pkg.duration_days*86400000).toISOString() : null;
  const {error:updateErr}=await db.from("licenses").update({status:"active",user_id:user.id,username:username||lic.username,device_id,expires_at:lic.expires_at||expiry}).eq("id",lic.id);
  if(updateErr) throw updateErr;
  return Response.json({success:true,expires_at:lic.expires_at||expiry},{headers:cors});
 }catch(e){return Response.json({error:String(e)},{status:400,headers:cors});}
});
