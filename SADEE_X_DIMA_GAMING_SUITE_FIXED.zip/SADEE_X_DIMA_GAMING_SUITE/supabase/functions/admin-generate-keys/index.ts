import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
function makeKey(){ const b=new Uint8Array(18); crypto.getRandomValues(b); return "SXD-"+Array.from(b).map(x=>x.toString(16).padStart(2,"0")).join("").toUpperCase(); }
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 try{
  const url=Deno.env.get("SUPABASE_URL")!, service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, anon=Deno.env.get("SUPABASE_ANON_KEY")!;
  const auth=req.headers.get("Authorization")??"";
  const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}}});
  const {data:{user}}=await userClient.auth.getUser();
  if(!user) return Response.json({error:"Unauthorized"},{status:401,headers:cors});
  const db=createClient(url,service);
  const {data:admin}=await db.from("admin_users").select("user_id").eq("user_id",user.id).maybeSingle();
  if(!admin) return Response.json({error:"Admin access required"},{status:403,headers:cors});
  const {package_id,count,username}=await req.json();
  const n=Math.max(1,Math.min(200,Number(count)||1));
  const {data:pkg,error:pe}=await db.from("packages").select("id,duration_days").eq("id",package_id).single();
  if(pe) throw pe;
  const rows=Array.from({length:n},()=>({license_key:makeKey(),package_id,username:username||null,status:"unused"}));
  const {data,error}=await db.from("licenses").insert(rows).select("id,license_key,package_id,status,created_at");
  if(error) throw error;
  return Response.json({keys:data},{headers:cors});
 }catch(e){return Response.json({error:String(e)},{status:400,headers:cors});}
});
