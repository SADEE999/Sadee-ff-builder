import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 try{
  const url=Deno.env.get("SUPABASE_URL")!, service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, anon=Deno.env.get("SUPABASE_ANON_KEY")!;
  const auth=req.headers.get("Authorization")??"";
  const uc=createClient(url,anon,{global:{headers:{Authorization:auth}}});
  const {data:{user}}=await uc.auth.getUser();
  if(!user) return Response.json({error:"Sign in required"},{status:401,headers:cors});
  const body=await req.json();
  const db=createClient(url,service);
  const {data:row,error}=await db.from("devices").upsert({
   user_id:user.id,device_id:String(body.device_id),username:body.username||null,
   model:body.model||null,manufacturer:body.manufacturer||null,android_version:body.android_version||null,
   total_storage_bytes:body.total_storage_bytes||null,available_storage_bytes:body.available_storage_bytes||null,last_seen:new Date().toISOString()
  },{onConflict:"device_id"}).select().single();
  if(error) throw error;
  if(row.access_suspended) return Response.json({access_suspended:true},{status:403,headers:cors});
  return Response.json({success:true},{headers:cors});
 }catch(e){return Response.json({error:String(e)},{status:400,headers:cors});}
});
