# Supabase deployment

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
supabase functions deploy create-order
supabase functions deploy admin-generate-keys
supabase functions deploy activate-license
supabase functions deploy register-device
```

Set secrets in the Supabase Dashboard under Edge Functions → Secrets. Do not add `SUPABASE_SERVICE_ROLE_KEY` to Android build config.
