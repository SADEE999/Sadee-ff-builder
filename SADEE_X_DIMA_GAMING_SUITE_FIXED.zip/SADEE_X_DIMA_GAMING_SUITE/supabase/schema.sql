
-- SADEE X DIMA Gaming Suite — Supabase schema
-- Run in Supabase SQL Editor. Never put service_role keys in Android apps.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.admin_users where user_id=auth.uid()) $$;

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  created_at timestamptz not null default now()
);
create table if not exists public.packages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  duration_days integer,
  price_lkr integer not null check(price_lkr >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
insert into public.packages(name,duration_days,price_lkr)
select v.name,v.days,v.price from (values
 ('7 Days',7,1000),('1 Month',30,2500),('Lifetime',null::integer,4500)
) as v(name,days,price)
where not exists(select 1 from public.packages p where p.name=v.name);

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  license_key text unique not null,
  package_id uuid references public.packages(id),
  username text,
  user_id uuid references auth.users(id),
  status text not null default 'unused' check(status in ('unused','active','revoked','expired')),
  device_id text,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  username text not null,
  package_id uuid references public.packages(id),
  package_name text not null,
  amount_lkr integer not null,
  phone text not null default '+94768472404',
  status text not null default 'pending' check(status in ('pending','paid','cancelled')),
  created_at timestamptz not null default now()
);
create table if not exists public.devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  device_id text not null unique,
  username text,
  model text,
  manufacturer text,
  android_version text,
  total_storage_bytes bigint,
  available_storage_bytes bigint,
  last_seen timestamptz not null default now(),
  access_suspended boolean not null default false
);

alter table public.admin_users enable row level security;
alter table public.profiles enable row level security;
alter table public.packages enable row level security;
alter table public.licenses enable row level security;
alter table public.orders enable row level security;
alter table public.devices enable row level security;

drop policy if exists "active packages readable" on public.packages;
create policy "active packages readable" on public.packages for select using(active or public.is_admin());
drop policy if exists "admin manage packages" on public.packages;
create policy "admin manage packages" on public.packages for all using(public.is_admin()) with check(public.is_admin());

drop policy if exists "profile owner read" on public.profiles;
create policy "profile owner read" on public.profiles for select using(user_id=auth.uid() or public.is_admin());
drop policy if exists "profile owner insert" on public.profiles;
create policy "profile owner insert" on public.profiles for insert with check(user_id=auth.uid());
drop policy if exists "profile owner update" on public.profiles;
create policy "profile owner update" on public.profiles for update using(user_id=auth.uid() or public.is_admin()) with check(user_id=auth.uid() or public.is_admin());

drop policy if exists "admin manage licenses" on public.licenses;
create policy "admin manage licenses" on public.licenses for all using(public.is_admin()) with check(public.is_admin());
drop policy if exists "user read own licenses" on public.licenses;
create policy "user read own licenses" on public.licenses for select using(user_id=auth.uid());

drop policy if exists "admin manage orders" on public.orders;
create policy "admin manage orders" on public.orders for all using(public.is_admin()) with check(public.is_admin());
drop policy if exists "user read own orders" on public.orders;
create policy "user read own orders" on public.orders for select using(user_id=auth.uid());

drop policy if exists "admin manage devices" on public.devices;
create policy "admin manage devices" on public.devices for all using(public.is_admin()) with check(public.is_admin());
drop policy if exists "user manage own device" on public.devices;
create policy "user manage own device" on public.devices for all using(user_id=auth.uid()) with check(user_id=auth.uid());

drop policy if exists "admin read self" on public.admin_users;
create policy "admin read self" on public.admin_users for select using(user_id=auth.uid() or public.is_admin());

-- Admin bootstrap: after creating your admin account in Authentication > Users,
-- insert its UUID manually:
-- insert into public.admin_users(user_id) values ('YOUR-AUTH-USER-UUID');
