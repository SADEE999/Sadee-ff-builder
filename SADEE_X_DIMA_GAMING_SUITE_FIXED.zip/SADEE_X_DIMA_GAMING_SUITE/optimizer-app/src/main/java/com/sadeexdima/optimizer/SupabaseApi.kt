package com.sadeexdima.optimizer

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object SupabaseApi {
    private val client = OkHttpClient.Builder().callTimeout(25, TimeUnit.SECONDS).build()
    private val base get() = BuildConfig.SUPABASE_URL.trimEnd('/')
    private val anon get() = BuildConfig.SUPABASE_ANON_KEY
    private val jsonType = "application/json".toMediaType()

    suspend fun signIn(email:String,password:String): JSONObject = withContext(Dispatchers.IO) {
        request("/auth/v1/token?grant_type=password","POST",JSONObject().put("email",email).put("password",password),null)
    }
    suspend fun signUp(email:String,password:String,username:String): JSONObject = withContext(Dispatchers.IO) {
        request("/auth/v1/signup","POST",JSONObject().put("email",email).put("password",password)
            .put("data",JSONObject().put("username",username)),null)
    }
    suspend fun select(table:String, token:String, query:String="select=*"): JSONArray = withContext(Dispatchers.IO) {
        request("/rest/v1/$table?$query","GET",null,token).getJSONArray("rows")
    }
    suspend fun edge(name:String,token:String,body:JSONObject):JSONObject = withContext(Dispatchers.IO) {
        request("/functions/v1/$name","POST",body,token)
    }
    suspend fun insert(table:String,token:String,body:JSONObject):JSONObject = withContext(Dispatchers.IO) {
        request("/rest/v1/$table","POST",body,token,"return=representation")
    }
    private fun request(path:String,method:String,body:JSONObject?,token:String?,prefer:String?=null):JSONObject {
        require(base.startsWith("https://") && !base.contains("YOUR_PROJECT")) { "Set SUPABASE_URL in Gradle properties first." }
        require(anon!="YOUR_SUPABASE_ANON_KEY") { "Set SUPABASE_ANON_KEY in Gradle properties first." }
        val builder=Request.Builder().url(base+path).header("apikey",anon).header("Accept","application/json")
        if(token!=null) builder.header("Authorization","Bearer $token")
        else builder.header("Authorization","Bearer $anon")
        if(body!=null) builder.method(method,body.toString().toRequestBody(jsonType)) else builder.method(method,null)
        if(body!=null) builder.header("Content-Type","application/json")
        if(prefer!=null) builder.header("Prefer",prefer)
        client.newCall(builder.build()).execute().use { response ->
            val text=response.body?.string().orEmpty()
            if(!response.isSuccessful) throw IllegalStateException("Supabase ${response.code}: $text")
            return if (text.isBlank()) JSONObject().put("success", true) else if (text.trim().startsWith("[")) JSONObject().put("rows", JSONArray(text)) else JSONObject(text)
        }
    }
}
