# SADEE GAMING POSTER PRO — V2.0

A complete Android Studio project for a Free Fire account showcase poster maker.

## Included
- Custom SADEE GAMING POSTER PRO app logo
- Premium dark neon dashboard and navigation
- Multiple screenshot upload from Android gallery
- Category assignment: Profile & Stats, Characters, Bundles / Outfits, Emotes, Gun Skins, Pets, Vehicles, Other Items
- Editable player name, UID, level, title and footer
- Royal Gold, Neon Purple and Crimson Fire themes
- Category-based compact poster layout
- HD PNG export to Pictures/SADEE Poster Pro
- GitHub Actions workflow to build a debug APK

## Build APK with GitHub Actions
1. Upload the contents of this ZIP to the root of a GitHub repository (not the ZIP itself).
2. Open Actions.
3. Select `SADEE GAMING POSTER PRO V2 - APK BUILDER`.
4. Click Run workflow.
5. Download the `SADEE-GAMING-POSTER-PRO-V2-APK` artifact after the build succeeds.

## Important feature note
This version lets the user assign each uploaded screenshot to a category and lays those screenshots out in separate category sections. It does not yet automatically recognize individual in-game objects inside a screenshot or cut them out with AI. Those require an image-recognition model and a separate integration.
