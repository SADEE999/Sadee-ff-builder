# SADEE X DIMA OPTIMIZER V2
Fresh Android starter with two independent apps: Optimizer and Admin. UI starter; license/admin functions are demo-only and require a secure backend.

Build in Android Studio or via GitHub Actions.
