SADEE EDITOR PRO - GitHub APK build

1. Extract this ZIP.
2. Upload the contents of sadee_apk_ready (including .github) to your GitHub repository root.
3. Remove or disable old workflow files in .github/workflows so only this build workflow runs.
4. Commit and push to main/master, or use Actions > SADEE EDITOR PRO APK BUILD > Run workflow.
5. Download the SADEE-EDITOR-PRO-APK artifact from the successful Actions run.

The workflow creates www from the original index.html, app.js and style.css before Capacitor sync.
