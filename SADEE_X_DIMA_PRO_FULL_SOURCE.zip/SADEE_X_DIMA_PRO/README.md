# SADEE X DIMA PRO — Android source package

Includes two independent Android apps:
- `optimizer-app`: customer-facing optimizer UI, device information, cleaning/settings shortcuts, gaming profiles and 20 tool entries.
- `admin-app`: dark neon admin dashboard with license demo generator, device/user page, optimizer controls, game profiles and settings.

## Build
Open this folder in Android Studio (JDK 17, Android SDK 35), or run:

```bash
gradle clean assembleDebug
```

GitHub Actions workflow: `.github/workflows/android-build.yml`. Push the project to a GitHub repository and run **Actions → SADEE X DIMA PRO Android Build**. APK artifacts will be attached to the workflow run.

## Important implementation notes
- This is a functional UI/source starter, not a production-ready commercial release.
- Admin-generated license keys are local demo keys only. No shared cloud database, customer authentication, device binding, remote revoke, or secure API is configured. Add a Firebase/Supabase/custom backend and server-side validation before selling licenses.
- The optimizer can clear only its own app cache. Android does not let an ordinary third-party app silently clear every other app's private cache or guarantee RAM/FPS boosts.
- Settings shortcuts open Android Settings where supported. Refresh-rate changes, CPU/GPU tuning, touch latency changes, and FPS unlocks are device/OS/vendor dependent and are not forced by this app.
- Device monitor shows only real values available through public Android APIs; unavailable readings are not fabricated.

## Branding
The app uses the SADEE × DIMA PRO name and a dark cyan/purple gaming theme. Replace the text logo with your final approved logo artwork before publishing.
