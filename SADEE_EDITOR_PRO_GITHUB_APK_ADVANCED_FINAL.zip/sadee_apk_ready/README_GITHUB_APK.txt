SADEE EDITOR PRO - GitHub APK build

Recommended: upload the contents of this folder (index.html, app.js, style.css, package.json, capacitor.config.json, and .github/workflows/build-apk.yml) to the ROOT of a GitHub repository. Do not upload this folder nested inside another folder if you want the workflow to detect it automatically.

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root and commit.
3. Open Actions. The workflow starts automatically on main/master pushes.
4. If needed, open Actions > Build SADEE EDITOR PRO APK > Run workflow.
5. Open the completed run and download the SADEE-EDITOR-PRO-APK artifact.
6. Extract the artifact ZIP and install app-debug.apk on your Android device.

The workflow uses GitHub's Ubuntu Android SDK installation and retries package setup. No build can be guaranteed to succeed in every environment; inspect the failed step logs if GitHub or package servers are unavailable.
